Approved images and rejection examples are embedded in the PDF. Use only APPROVED image pages as generation references.
